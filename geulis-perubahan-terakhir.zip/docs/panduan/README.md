# Manual peran GEULIS

Panduan pemakaian untuk enam peran (cetak biru §2.3). Versi Markdown ini
untuk repositori; HTML dan PDF untuk dibagikan (WhatsApp, USB, cetak).

| Markdown | HTML | PDF | Siapa | Setelah masuk |
|---|---|---|---|---|
| [siswa.md](siswa.md) | [siswa.html](siswa.html) | [siswa.pdf](siswa.pdf) | Peserta belajar | `/belajar` — **Halo, [nama]** |
| [guru.md](guru.md) | [guru.html](guru.html) | [guru.pdf](guru.pdf) | Guru matematika mitra | `/guru` — **Selamat datang** |
| [validator.md](validator.md) | [validator.html](validator.html) | [validator.pdf](validator.pdf) | Ahli / praktisi | tautan `/validasi/{token}` — **tanpa akun** |
| [observer.md](observer.md) | [observer.html](observer.html) | [observer.pdf](observer.pdf) | Pembantu lapangan | `/observasi` — **Lembar observasi** |
| [peneliti.md](peneliti.md) | [peneliti.html](peneliti.html) | [peneliti.pdf](peneliti.pdf) | Tim peneliti | `/riset/kelengkapan` — **Kelengkapan data** |
| [admin.md](admin.md) | [admin.html](admin.html) | [admin.pdf](admin.pdf) | Pengelola sistem | `/admin` — dasbor Filament |

**Bagikan satu berkas:** buka [index.html](index.html) di peramban (pilih tab
peran, atau `#siswa` `#guru` `#validator` `#observer` `#peneliti` `#admin`
di akhir alamat). Tidak perlu server.

Siswa dan guru memakai HP (lebar 360 px). Peneliti dan admin boleh laptop.
Validator **tidak** masuk lewat `/masuk`.

Alamat latihan lokal: http://localhost:8020  
Kolom pertama di `/masuk` berlabel **NIS**; staf mengetik **username**.
Kolom kedua **PIN atau sandi**.

Bukan untuk server sekolah. Data akun di bawah hasil `geulis:seed-simulasi`.

```bash
docker exec geulis-php php artisan geulis:seed-simulasi
```

Idempoten: menjalankan ulang tidak menggandakan kelas. Perintah mencetak
tautan validator yang berlaku di mesin ini.

---

## Ke mana masing-masing diantar

Setelah **Masuk** berhasil, sistem mengantar sesuai peran (bukan ke beranda
umum):

| Peran | Halaman pertama | Judul yang tampak |
|---|---|---|
| Siswa, belum persetujuan | `/belajar/persetujuan` | Persetujuan Penelitian |
| Siswa, sudah setuju, belum asesmen | `/belajar` | Halo, [nama] + kartu asesmen |
| Siswa, sudah asesmen | `/belajar` | Halo, [nama] + tiga kotak + lima pertemuan |
| Guru | `/guru` | Selamat datang, [nama] |
| Observer | `/observasi` | Lembar observasi |
| Peneliti | `/riset/kelengkapan` | Kelengkapan data |
| Admin | `/admin` | Dasbor Geulis (Filament) |

Setiap layar siswa/guru/observer/peneliti punya kop **GEULIS** di kiri dan
tombol **Keluar** di kanan. Panel admin memakai menu samping Filament.

---

## Akun latihan

Kata sandi staf: `password`  
PIN siswa yang dikunci tercantum di bawah. Siswa lain punya PIN acak —
lihat **Kartu PIN** di akun guru.

| Peran | Username / NIS | PIN / sandi | Setelah masuk |
|---|---|---|---|
| Admin | `admin` | `password` | `/admin` |
| Peneliti | `peneliti-sim` | `password` | `/riset/kelengkapan` |
| Guru XI-3 & XI-4 (SMAN 2 Tasikmalaya) | `guru-sim-1` | `password` | `/guru` |
| Guru XI-2 & XI-5 (SMAN 1 Ciamis) | `guru-sim-2` | `password` | `/guru` |
| Observer 1 | `observer-sim-1` | `password` | `/observasi` |
| Observer 2 | `observer-sim-2` | `password` | `/observasi` |
| Siswa tuntas (XI-3) | `20260301` | `482913` | `/belajar` |
| Siswa perlu pendampingan (XI-3) | `20260313` | `739182` | `/belajar` |
| Siswa belum mulai (XI-3) | `20260320` | `615204` | persetujuan dulu |

Panel Filament juga menerima surel `admin@geulis.test` / `password` di `/admin`.

Validator: salin tautan dari keluaran perintah, atau dari
**Peneliti → V-02 Aiken**. Pakai undangan yang statusnya belum `selesai`
(Dr. Ahli Etnomatematika) untuk mengisi lembar.

---

## Apa yang sudah terisi

Empat kelas × 20 siswa. Dua eksperimen (XI-3 Tasik, XI-2 Ciamis), dua
kontrol (XI-4, XI-5). Jejak belajar (asesmen, tes CT, pertemuan, motif,
angket, observasi, Aiken) dihasilkan lewat layanan asli, bukan disisip
langsung.

| Kelas | Kelompok | Yang terlihat |
|---|---|---|
| XI-3 SMAN 2 | eksperimen | Papan hidup: eskalasi, override, produk, angket |
| XI-4 SMAN 2 | kontrol | Tes CT, tanpa jalur pertemuan |
| XI-2 SMAN 1 Ciamis | eksperimen | Observasi P1 sudah ada |
| XI-5 SMAN 1 Ciamis | kontrol | Dua siswa belum pretest → peringatan P-01 |

**Akun pengembangan** (`guru1`, NIS `0056781234`) ikut dari DemoSeeder.
Jangan dipakai untuk latihan peran — datanya tipis, satu pertemuan.
