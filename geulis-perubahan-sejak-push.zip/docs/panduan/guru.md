# Manual guru

Untuk guru matematika mitra. HP atau laptop. Anda **tidak** menyunting
butir tes dan **tidak** mengekspor data penelitian (itu peneliti).

Masuk: alamat yang admin berikan (latihan lokal: http://localhost:8020/masuk)  
Username di kolom **NIS**. Sandi di kolom **PIN atau sandi**.

Setiap layar punya kop **GEULIS** dan tombol **Keluar**.

---

## Halaman setelah masuk — Beranda `/guru`

Judul: **Selamat datang, [nama Anda]**. Subjudul: *Kelas yang Anda ampu.*

Yang tampak dari atas ke bawah:

1. Dua kartu: **Penilaian uraian** dan **Perlu pendampingan**.
2. Kartu oranye **Isi angket respons guru** — hanya jika angket diaktifkan.
3. Kartu **Nilai produk P1 … P5** untuk setiap pertemuan yang sudah terbit.
4. Daftar kelas: nama, sekolah, tahun ajaran, jumlah siswa, **kode gabung**.
5. Tombol oranye **Buat kelas baru**.

Ketuk sebuah kelas untuk masuk ke detailnya. Kelas kosong menampilkan
*Belum ada kelas. Buat kelas pertama Anda di bawah.*

### Buat kelas baru

Formulir: nama kelas, tahun ajaran (`2026/2027`), sekolah, lalu kotak
**Daftar siswa (opsional)**. Tempel NIS dan nama, satu baris satu siswa:

```
0056781234 Reza Pratama
0056781235 Siti Aminah
```

NIS yang sudah ada tidak dibuat ulang — siswa itu hanya ditambahkan ke
kelas ini (boleh dua kelas). Sandi awal akun baru: `siswa-1234`.

---

## Peta layar setelah beranda

| Layar | Alamat | Yang Anda lihat |
|---|---|---|
| **Detail kelas** | `/guru/kelas/…` | Kode gabung, impor tempel/CSV, daftar siswa, cetak PIN |
| **Papan kelas** | `/guru/kelas/…/papan` | Zona pendampingan, peta panas M, tombol **Ubah** level |
| **Rapor siswa** | `/guru/siswa/…` | Satu siswa: level, jejak aturan, override, tes CT |
| **Penilaian rubrik** | `/guru/penilaian/…` | Karya pertemuan; skor 0–100 dari empat kriteria |
| **Penilaian uraian** | `/guru/penilaian-uraian` | Antrean jawaban uraian tes CT, skor 0–4 |
| **Perlu pendampingan** | `/guru/pendampingan` | Antrian `RULE_ESCALATE`; **Sudah didampingi** |
| **Kartu PIN** | `/guru/kartu-pin/…` | Halaman cetak NIS + PIN 6 digit (tab baru) |
| **Angket guru** | `/guru/angket` | Muncul dari kartu oranye di beranda |

### Detail kelas

Kop: **← Semua kelas**, lalu nama kelas dan kode gabung. Kartu oranye
**Buka papan kelas**. Tiga cara menambah siswa: tempel NIS+nama, CSV
(`nama, nis, jenis_kelamin`), atau satu per satu. Daftar siswa menampilkan
NIS, kode `S-…`, tombol **PIN baru** dan **Keluarkan**.

### Papan kelas

Ringkasan: jumlah siswa, kelompok riset, berapa yang aktif / belum mulai.
Kotak peringatan **Perlu pendampingan langsung**. Tabel peta panas
(hijau ≥ 0,80 … merah < 0,50). **Ubah** membuka lembar override: pilih
level, isi alasan wajib, **Simpan override**.

Override menaikkan atau menurunkan **satu tingkat**. Alasan tersimpan dan
ikut diekspor peneliti.

### Rapor siswa

Tiga kotak: level kini, level awal · R, modus. Jejak keputusan sistem
(`kode_aturan`), daftar override guru, tes CT per indikator, karya motif.

---

## Urutan kerja di kelas

1. Masuk. Pastikan kelas Anda tampak di beranda.
2. Buka kelas → **Cetak kartu PIN** sebelum pertemuan pertama.
3. Buka **Papan** setiap pertemuan: datangi zona pendampingan dulu.
4. Nilai **uraian CT** yang menunggu, lalu **produk** pertemuan yang sudah
   dikumpulkan.
5. Isi **angket respons guru** jika kartunya muncul.

---

## Yang tidak boleh

- Membacakan jawaban tes CT.
- Mengganti NIS siswa dengan surel.
- Membagikan satu akun guru ke seluruh ruang.
- Menghapus siswa yang pindah — nonaktifkan dari panel admin, atau
  keluarkan dari kelas ini saja.

Keluar: tombol **Keluar** di kop. Jangan biarkan sesi terbuka di laptop
ruang guru.

---

## Akun latihan (hanya mesin `seed-simulasi`)

| Username | Sandi | Kelas |
|---|---|---|
| `guru-sim-1` | `password` | XI-3 & XI-4 SMAN 2 Tasikmalaya |
| `guru-sim-2` | `password` | XI-2 & XI-5 SMAN 1 Ciamis |

Papan XI-3: tiga siswa di zona pendampingan. Buka rapor `20260313` untuk
melihat alasan override.
