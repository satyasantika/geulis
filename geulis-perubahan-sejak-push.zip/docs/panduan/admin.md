# Manual admin

Pengelola sistem. Laptop. Anda menambah akun, sekolah, kelas, menerbitkan
konten, dan memicu **simulasi**. Anda **bukan** pengawas ruangan.

Dua pintu masuk:

| Pintu | Alamat | Kredensial |
|---|---|---|
| Masuk web (NIS + sandi) | `/masuk` | username `admin`, sandi akun |
| Panel Filament | `/admin` | surel + sandi (latihan: `admin@geulis.test`) |

Setelah `/masuk` berhasil, Anda **langsung ke `/admin`**, bukan ke `/guru`
atau `/belajar`.

Latihan lokal: http://localhost:8020/masuk dan http://localhost:8020/admin  
Akun seed: `admin` / `password`. Akun `admin` juga punya peran peneliti,
jadi `/riset/*` bisa dibuka.

---

## Halaman setelah masuk — dasbor `/admin`

Ini **bukan** layar siswa. Tampilan Filament: merek **Geulis**, menu
samping (HP: ikon hamburger), dasbor dengan widget akun.

Menu samping, dari atas:

| Menu | Untuk apa |
|---|---|
| **Dashboard** | Ringkasan panel |
| **Pengguna** | Nama, username (NIS/NIP), peran, aktif; **Impor massal** |
| **Sekolah** | NPSN, nama, kabupaten/kota |
| **Kelas** | Guru, tahun ajaran, kelompok riset, kode gabung |
| **Pertemuan** | Lima pertemuan; centang **terbit** sebelum siswa melihat |
| **Varian konten** | Teks per level/modus (±140 di lapangan) |
| **Aktivitas** | Kuis, motif, refleksi |
| **Aset budaya** | Foto/SVG + `perajin_sumber`, `lokasi`, `tanggal_dokumentasi`, `izin_diperoleh` |
| **Tes CT** / **Butir tes CT** | Pretest–posttest, kunci, uraian |
| **Simulasi** | Kelas & akun sementara + layar QR — **hanya peran admin** |
| **Parameter adaptasi** | α, ambang, batas remedial — **hanya lihat**, tidak disunting dari sini |

Profil (nama, sandi) di ikon pengguna kanan atas. Lupa sandi panel memakai
surel (di lokal: log).

Peneliti yang masuk `/admin` **tidak** melihat menu Simulasi.

---

## Pengguna — impor massal

Di daftar Pengguna, tombol **Impor massal**. Format satu baris:

```
role, username, nama, password
siswa,0056781234,Reza Pratama,siswa-1234
guru,197812312345,Vepi Nurhasanah,password
```

Username siswa = NIS, guru = NIP. Akun yang sudah ada tidak digandakan —
peran ditambahkan. Sandi akun lama tidak diubah. Impor ini **tidak**
memasukkan siswa ke kelas; itu tugas guru di `/guru`.

---

## Simulasi — trigger dari admin

Menu **Simulasi → Buat**. Tiga angka: jumlah kelas (maks 12), guru (12),
siswa (80). Sistem membuat sekolah *Sekolah Simulasi #…*, kelas `non_riset`
bernama Sim n, akun `sim{id}g{n}` / `sim{id}s{n}`. Siswa simulasi tidak
masuk analisis (persetujuan tidak, kode `T-…`).

Di daftar: **Layar QR** (tab baru, satu kode per peserta) dan **Hapus**
(kelas + akun sementara ikut hilang; data penelitian tidak tersentuh).

Alur QR: proyektor menampilkan satu QR → peserta pindai → HP menampilkan
**Masuk sebagai [nama]** → ketuk **Masuk** → token terkunci → QR berikutnya
muncul. Prefetch tidak mengklaim token.

Jangan menjalankan `geulis:seed-simulasi` di produksi. Simulasi QR ini
boleh dibuat dan dihapus kapan pun.

---

## Urutan kerja lapangan

1. **Pengguna** — satu orang satu akun. Boleh lebih dari satu peran. Siswa
   pindah: nonaktifkan, jangan hapus.
2. **Sekolah** lalu **Kelas** — isi `kelompok_riset` (eksperimen / kontrol /
   uji_terbatas) sebelum pengambilan data.
3. **Pertemuan** terbit hanya yang siap. Konten P1–P5 di **Varian konten**;
   gambar lapangan di **Aset budaya** (WebP ≤ 200 KB + izin).
4. Ganti sandi `admin` sebelum mesin sekolah.

Cadangan: basis `db_geulis` + `storage/app` (produk siswa, ekspor).
Prosedur Docker: `docs/CATATAN-DOCKER.md`.

---

## Yang tidak boleh

- DemoSeeder / SimulasiSeeder di server sekolah.
- Membagikan satu login admin ke seluruh tim.
- Menaruh nama siswa pada berkas yang keluar dari sistem.
- Mengubah `config/geulis.php` setelah validasi ahli dimulai.
