# Manual siswa

Satu lembar. Dibacakan guru sebelum PIN dibagikan. Siswa memakai HP sendiri.

Masuk: alamat yang guru berikan (latihan lokal: http://localhost:8020/masuk)

Setiap layar punya kop **GEULIS** di kiri dan tombol **Keluar** di kanan.

---

## Yang kamu butuhkan

- HP sendiri, baterai cukup untuk satu pertemuan
- Kartu PIN dari guru: **NIS** dan **PIN 6 digit** (atau sandi awal jika guru
  baru mendaftarkanmu)
- Kuota sendiri. Jangan pinjam HP teman.

---

## Cara masuk

1. Buka tautan. Tampak logo **GEULIS**, kolom **NIS**, kolom **PIN atau
   sandi**, tombol **Masuk**.
2. Ketik NIS, ketik PIN, tekan **Masuk**.
3. Sistem mengantarmu ke halaman belajarmu — bukan ke beranda umum.

---

## Halaman setelah masuk

Urutannya selalu sama. Kamu tidak melewati langkah yang belum selesai.

### 1. Persetujuan Penelitian — `/belajar/persetujuan`

Muncul **hanya** bila kamu belum memilih. Judul: **Persetujuan Penelitian**.

Kotak oranye menjelaskan apa yang dikumpulkan (jawaban, waktu, karya) dan
apa yang **tidak** (NIK, alamat, nomor HP, foto wajah). Namamu diganti kode
`S-…` di laporan.

Dua pilihan, keduanya tetap boleh belajar:

- *Saya bersedia data belajar saya dipakai untuk penelitian.*
- *Saya tidak bersedia — saya tetap ingin belajar di sini.*

Tombol **Lanjut**. Yang menolak hanya dikeluarkan dari analisis peneliti,
bukan dari kelas.

### 2. Jalur Belajarmu — `/belajar` (beranda siswa)

Judul: **Halo, [namamu]**. Ini halaman utama setelah persetujuan.

**Kalau asesmen awal belum dikerjakan**, hanya satu kartu:

- judul *Mulai dari asesmen awal*
- tombol oranye **Mulai asesmen awal**

**Kalau asesmen sudah selesai**, yang tampak:

| Bagian | Isi |
|---|---|
| Tiga kotak | **Titik mulai** (L1/L2/L3), **Cara belajar**, **Artefak utama** |
| Kartu putih | **Kemajuanku →** |
| Kartu oranye (jika tes aktif) | Tes awal / tes akhir + **Mulai tes** |
| Kartu oranye (jika lima pertemuan selesai) | **Isi angket respons** |
| Daftar | **Lima pertemuan** — terbuka, selesai, atau terkunci |

Pertemuan terkunci bertuliskan *Terbuka setelah pertemuan sebelumnya
selesai* atau *Belum dibuka guru.* Pertemuan 5 punya tautan tambahan
**Proyek akhir**.

Titik mulai bisa berubah seiring kemajuan — itu posisi sementara, bukan
label.

### 3. Asesmen awal — `/belajar/asesmen-awal`

Tiga tahap di puncak layar: **1. Tes kesiapan › 2. Profil belajar ›
3. Minat budaya**. Satu butir per layar pada tes kesiapan; angket
beberapa butir per halaman. Bukan nilai rapor. Jawaban tersimpan sendiri.
Setelah selesai, kamu kembali ke **Halo**.

### 4. Pertemuan — `/belajar/pertemuan/…`

Judul pertemuan, capaian, lalu daftar **tujuh bagian** (nomor di lingkaran).
Yang selesai bertanda centang hijau. Tombol **Lanjut: [bagian berikutnya]**.

### 5. Unit (satu bagian) — `/belajar/unit/…`

Kop: *Bagian n dari 7* dan lencana level · cara belajar. Foto/motif budaya
dengan nama perajin. Teks, kadang GeoGebra, lalu kuis atau Motif Builder
atau refleksi.

Urutan tipikal satu pertemuan: jangkar budaya → eksplorasi → formalisasi →
latihan → pemeriksaan → motif / refleksi.

### 6. Motif Builder

Dua kanvas: **Sasaran** (kiri) dan **Hasilmu** (kanan). Susun perintah
**GESER, PUTAR, PERBESAR, ULANGI**. Persentase kemiripan muncul di kanan.
Boleh coba lagi.

### 7. Tes CT — kartu oranye di Halo

Pewaktu dari server. Soal pilihan ganda dinilai otomatis; uraian dinilai
guru. Hasil muncul di **Kemajuanku**. Kerjakan sendiri.

### 8. Kemajuanku — `/belajar/kemajuan`

Empat batang kemampuan berpikir komputasional, grafik penguasaan per
pertemuan, galeri motif, umpan balik rubrik (setelah karya dinilai).

### 9. Proyek akhir (Pertemuan 5)

Pilih bentuk: desain motif, laporan algoritmik, video (tautan), atau
poster. Baca rubrik sebelum mengerjakan. Berkas privat — hanya kamu, guru
kelas, dan peneliti yang boleh membuka.

---

## Kalau ada yang bermasalah

| Yang terjadi | Yang dilakukan |
|---|---|
| NIS atau PIN belum cocok | Periksa kartu. Lima kali salah mengunci 60 detik. |
| Akun tidak aktif | Angkat tangan. Guru yang mengaktifkan. |
| Sinyal putus | Jangan tutup tab. Lanjutkan begitu daring. Tes CT menahan jawaban di HP. |
| Lupa PIN | Minta guru mengatur ulang dari kartu PIN / daftar siswa. |

Namamu diganti kode `S-…` di semua laporan. Itu bukan nilai rapor.

---

## Akun latihan (hanya mesin `seed-simulasi`)

| NIS | PIN | Keadaan | Halaman pertama |
|---|---|---|---|
| `20260301` | `482913` | Tuntas | Halo + lima pertemuan selesai |
| `20260313` | `739182` | Perlu pendampingan | Halo + jalur hidup |
| `20260320` | `615204` | Belum mulai | Persetujuan Penelitian |
