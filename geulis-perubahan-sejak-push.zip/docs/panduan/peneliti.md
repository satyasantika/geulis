# Manual peneliti

Tim peneliti. Laptop. Anda melihat kelengkapan, analitik, undangan
validator, dan ekspor. Konten pertemuan disunting admin; mengajar
dilakukan guru.

Masuk: alamat sistem (latihan lokal: http://localhost:8020/masuk)  
Username di kolom **NIS**. Sandi di kolom **PIN atau sandi**.

Kop **GEULIS** dan tombol **Keluar**. Di bawah kop, **empat pil navigasi**
selalu ada di keempat layar riset.

---

## Halaman setelah masuk — P-01 Kelengkapan `/riset/kelengkapan`

Langsung ke sini, bukan ke dasbor admin (kecuali akun Anda juga admin).

Pil: **P-01 Kelengkapan** (aktif) · P-02 Analitik · V-02 Aiken · P-03
Ekspor · **Panel admin** (hanya berguna jika Anda juga peran admin).

Judul: **Kelengkapan data**. Subjudul: *n sekolah · n kelas riset · n
siswa*.

Tabel per kelas: kelompok, n, asesmen awal, pretest, P1–P5, posttest,
angket. Angka merah bila kurang dari n. Peringatan oranye di bawah tabel
(pretest kurang, persetujuan belum dijawab).

Kelas `non_riset` (termasuk kelas simulasi QR) **tidak** masuk tabel ini.
Siswa yang menolak persetujuan tidak masuk analisis.

---

## Peta layar

| Kode | Judul di layar | Alamat | Isi |
|---|---|---|---|
| P-01 | Kelengkapan data | `/riset/kelengkapan` | Tabel kelengkapan + peringatan |
| P-02 | Analitik penelitian | `/riset/analitik` | N-Gain eksperimen vs kontrol, indikator CT, kepraktisan |
| V-02 | Validasi ahli | `/riset/validasi` | Undang validator, salin tautan, rekap V |
| P-03 | Ekspor data | `/riset/ekspor` | Buat .xlsx anonim, riwayat unduh |

Akun `peneliti-sim` latihan **tidak** memegang peran admin. Tautan
**Panel admin** akan ditolak.

### P-02 Analitik

Dua kartu besar: N-Gain rerata eksperimen dan kontrol. Tabel per
indikator CT. Daftar per kelas. Kepraktisan angket. Hanya siswa yang
bersedia diteliti dan sudah pretest + posttest. Uji-t tetap di SPSS/JASP
— halaman menuliskannya.

### V-02 Aiken

Formulir **Undang validator**: instrumen, nama wajib, surel opsional.
**Buat tautan undangan** — sistem **tidak** mengirim surel; salin kotak
monospace ke WhatsApp. Daftar undangan berstatus. Kartu V keseluruhan,
butir memenuhi, perlu revisi. Unduh saran `.csv`.

### P-03 Ekspor

Teks: selalu kode anonim `S-…`. Tombol **Buat ekspor sekarang**. Daftar
riwayat + **Unduh**. Dibatalkan bila `anonimkan_ekspor=false` atau nama/NIS
siswa lolos ke sel.

---

## Urutan kerja

1. **Kelengkapan.** Cek peringatan sebelum analisis.
2. **Analitik.** Bandingkan eksperimen vs kontrol setelah posttest ada.
3. **V-02.** Undang ahli, salin tautan.
4. **Ekspor.** Unduh dari layar atau `php artisan geulis:ekspor`.

Jangan menjanjikan nilai rapor ke sekolah. Yang boleh dikatakan: kode
anonim, kelompok riset, dan bahwa data pribadi tidak keluar.

---

## Yang tidak boleh

- `anonimkan_ekspor=false` di mesin lapangan.
- Membagikan tautan validator di grup siswa.
- Mengubah skor Aiken secara manual.

---

## Akun latihan (hanya mesin `seed-simulasi`)

Username `peneliti-sim` / `password` → `/riset/kelengkapan`.  
XI-5 menampilkan peringatan pretest kurang. Tiga validator simulasi sudah
selesai; satu menunggu.
