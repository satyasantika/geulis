# Manual observer

Pembantu lapangan. Duduk di belakang kelas, HP sendiri. Anda **tidak**
mengajar dan **tidak** menilai siswa.

Masuk: alamat yang admin berikan (latihan lokal: http://localhost:8020/masuk)  
Username di kolom **NIS**. Sandi di kolom **PIN atau sandi**.

Kop **GEULIS** dan tombol **Keluar**.

---

## Halaman setelah masuk — `/observasi`

Satu layar. Judul: **Lembar observasi**. Subjudul menjelaskan skala 1
(tidak terlaksana) – 4 (terlaksana sangat baik) dan bahwa isian bisa
tanpa sinyal.

Yang tampak:

1. Status **Mode luring** (jika tanpa sinyal) dan jumlah isian menunggu kirim.
2. Tiga pilihan: **Kelas**, **Pertemuan**, **tanggal**.
3. Daftar butir (10 pernyataan). Tiap butir empat tombol skor 1–4.
4. Kotak **Catatan lapangan**.
5. Tombol **Simpan**.
6. Di bawah: daftar lembar yang sudah **Terkirim** (jika ada).

Tidak ada menu lain. Anda tidak masuk ke `/belajar` atau `/guru`.

---

## Mengisi

1. Pilih kelas, pertemuan, dan tanggal.
2. Skor setiap butir. Catatan singkat: sinyal, HP kecil, guru mendatangi
   siapa.
3. **Simpan**. Satu lembar per (kelas, pertemuan, tanggal) per observer.

Isian dipegang di HP dulu. Kalau Wi-Fi putus, antrean tetap ada dan
terkirim otomatis saat daring. Jangan hapus data peramban sebelum status
**Terkirim.**

Buka halaman ini **sebelum** masuk mode pesawat.

---

## Latihan (`seed-simulasi`)

Username: `observer-sim-1` atau `observer-sim-2` · sandi `password`.

Empat lembar sudah ada: XI-3 pertemuan 1–3 dan XI-2 pertemuan 1. Isi
lembar **baru** (tanggal hari ini) supaya antrean luring bisa diuji:
airplane mode → isi → simpan → nyalakan sinyal.
