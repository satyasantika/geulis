# Manual validator (ahli)

Ahli materi, media, etnomatematika, atau praktisi. **Tidak perlu akun.**
Peneliti mengirim tautan bertanda (biasanya WhatsApp). Tautan itu adalah
kunci masuk — jangan buka `/masuk`.

Latihan lokal: jalankan `php artisan geulis:seed-simulasi` lalu salin
baris **Dr. Ahli Etnomatematika** (status belum selesai).

---

## Halaman setelah tautan dibuka — `/validasi/{token}`

Bukan layar masuk. Langsung lembar. Kop kecil: *GEULIS · validasi ahli*.

Yang tampak:

| Bagian | Isi |
|---|---|
| Judul | Nama instrumen |
| Subjudul | Nama Anda · *Aspek n dari 4* · *x dari 28 butir terisi* |
| Batang kemajuan | Oranye, terisi otomatis |
| Butir | Pernyataan + skala 1 … skala maksimum (biasanya 5) + saran opsional |
| Tombol | **Aspek berikutnya** / **Sebelumnya** / **Kirim lembar** (aspek terakhir) |

Jawaban tersimpan saat dipilih. Saran berguna bila skor 1–3.

Setelah **Kirim lembar**, layar hijau: *Terima kasih. Lembar Anda sudah
terkirim.* Skor langsung masuk Aiken's V di sisi peneliti. Skor tidak
bisa diubah.

Kalau tautan ditolak atau kedaluwarsa, minta peneliti mengirim ulang dari
**V-02 Aiken**.

---

## Cara mengisi

1. Buka tautan di HP atau laptop. Jangan teruskan ke orang lain.
2. Nama Anda sudah tertera. Skala 1 (sangat tidak sesuai) sampai nilai
   maksimum instrumen.
3. Isi per aspek. **Aspek berikutnya** sampai butir terakhir, lalu kirim.

---

## Yang dinilai

Kesesuaian materi, keterbacaan, keterlaksanaan di HP, dan ketepatan
aturan diferensiasi — sesuai pernyataan pada lembar. Ini **bukan** nilai
siswa.

Tiga undangan simulasi sudah selesai (materi, media, praktisi) supaya
rekap V tampak. Satu sengaja kosong untuk Anda coba.
